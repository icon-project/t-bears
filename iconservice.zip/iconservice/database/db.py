# -*- coding: utf-8 -*-

# Copyright 2017-2018 theloop Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import hashlib


def sha3_256(data: bytes):
    return hashlib.sha3_256(data).digest()


class IconScoreDatabase(object):
    """It is used in IconScore

    IconScore can access its states only through IconScoreDatabase
    """
    def __init__(self, icon_score: 'IconScoreBase', prefix: bytes=b'') -> None:
        """Constructor

        :param icon_score:
        :param prefix:
        """
        self.__prefix = prefix
        self.__icon_score = icon_score

    def get(self, key: bytes) -> bytes:
        key = self.__hash_key(key)
        return self.__icon_score.get_from_db(key)

    def put(self, key: bytes, value: bytes):
        key = self.__hash_key(key)
        self.__icon_score.put_to_db(key, value)

    def get_sub_db(self, prefix: bytes) -> 'IconScoreDatabase':
        return IconScoreDatabase(self.__icon_score, self.__prefix + prefix)

    def delete(self, key: bytes):
        key = self.__hash_key(key)
        self.__icon_score.delete_from_db(key)

    def __hash_key(self, key: bytes):
        """All key is hashed and stored to StateDB
        """
        key = sha3_256(self.__prefix + key)
        return key
